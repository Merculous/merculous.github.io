#import <UIKit/UIKit.h>

@interface CSGradientView : UIView

@end
