# yalu
source code of an incomplete ios 8.4.1 jailbreak.

Run the following command to download and try out the jailbreak on a Mac OS X system with XCODE.

```git clone https://github.com/kpwn/yalu && cd yalu && ./run.sh```
