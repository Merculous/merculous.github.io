yalu untether for ios841
by qwertyoruiopkjc

thanks @ panguteam


== this is partially closed source, don't compile ==
