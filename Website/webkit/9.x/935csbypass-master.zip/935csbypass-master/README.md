# 935csbypass

fixed in 10.

drop this code into any app and it should allow you to load arbitrary code in it.


my own bug this time
