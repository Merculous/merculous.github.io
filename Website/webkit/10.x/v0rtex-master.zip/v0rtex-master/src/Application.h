#import <UIKit/UIKit.h>

@interface Application : UIApplication

@end
