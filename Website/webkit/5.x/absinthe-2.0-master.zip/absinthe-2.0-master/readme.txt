~~~~~~~~~~~~~~~~~~~~~~~~
Greenpois0n Absinthe 2.0
~~~~~~~~~~~~~~~~~~~~~~~~

http://greenpois0n.com/


DESCRIPTION: 

- Absinthe 2.0 is an untethered jailbreak for iOS 5.1.1 devices


SYSTEM REQUIREMENTS:

- MacOSX 10.5/10.6/10.7/10.8
- Windows XP/Vista/7
- Linux x86/x86_64 (Kernel >= 2.6.15, libgtk+-2.0 >= 2.22.1)


SUPPORTED FIRMWARE: 5.1.1

SUPPORTED DEVICES:

- iPad3 (WiFi/CDMA/Global)
- iPad2 (WiFi/CDMA/GSM)
- iPad1
- iPhone 4S
- iPhone 4 (GSM), iPhone 4 (CDMA)
- iPhone 3GS
- iPod 4G
- iPod 3G


NOT SUPPORTED DEVICES:

- iPad2 WiFi R2 (new model)
- AppleTV 2
- AppleTV 3


USAGE: (MacOSX, Windows & Linux)

1. Make a backup of your device iTunes by right clicking on your device name under the 'Devices' menu and click 'Back Up'.
2. Once your backup is complete return to your device and go to Settings - General - Reset - Erase All Content and Settings. This will make the jailbreak process much faster.
3. Open Absinthe and be sure your are still connected via USB cable to your computer.
4. Click 'Jailbreak' and wait... just be patient and do not disconnect your device!
5. Once jailbroken return to iTunes and restore your backup from earlier. To do so, right click on your device name under the 'Devices' menu in the left panel of iTunes and click 'Restore From Backup...' then select the latest backup you created before. (restoring this backup will return all the content previously on your device, i.e. apps, photos, etc.) 
6. Thanks for using Absinthe, enjoy your jailbroken iDevice!


NOTES: 

a) If your device is already jailbroken, there is no reason to re-apply the jailbreak if a newer version of Absinthe is released. For information on updates please refer to 'changelog.txt'.


CONTACT/HELP:

- IRC: join #greenpois0n on irc.chronic-dev.org


CREDITS:

5.1.1 Exploits by: @pod2g, @planetbeing, @pimskeks
Artwork by @iOPK.
GUI by: Hanene Samara & @pimskeks.
Servers proudly supplied by Chronic-Dev, LLC (@chronicdevteam)

