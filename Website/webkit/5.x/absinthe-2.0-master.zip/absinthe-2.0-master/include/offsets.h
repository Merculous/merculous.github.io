// GreenPois0n Absinthe - offsets.h
// Copyright (C) 2011 Chronic-Dev Team
