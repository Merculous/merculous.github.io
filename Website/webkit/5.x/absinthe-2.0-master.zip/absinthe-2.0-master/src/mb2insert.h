/*
 * mb2insert.h
 *
 *  Created on: Jan 15, 2012
 *      Author: posixninja
 */

#ifndef MB2INSERT_H_
#define MB2INSERT_H_

int mb2insert(int argc, char* argv);

#endif /* MB2INSERT_H_ */
