/*
 * boolean.h
 *
 *  Created on: Dec 19, 2011
 *      Author: posixninja
 */

#ifndef BOOLEAN_H_
#define BOOLEAN_H_

typedef enum {
	kFalse = 0, kTrue = 1
} boolean_t;

#endif /* BOOLEAN_H_ */
