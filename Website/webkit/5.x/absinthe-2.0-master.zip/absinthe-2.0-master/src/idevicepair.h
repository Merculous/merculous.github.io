/*
 * idevicepair.h
 *
 *  Created on: Jan 14, 2012
 *      Author: posixninja
 */

#ifndef IDEVICEPAIR_H_
#define IDEVICEPAIR_H_

int idevicepair();
int idevicevalidate();


#endif /* IDEVICEPAIR_H_ */
