#ifndef IDEVICEBACKUP2_H
#define IDEVICEBACKUP2_H

int idevicebackup2(int argc, char** argv);
void idevicebackup2_set_clean_exit(int sig);

#endif
