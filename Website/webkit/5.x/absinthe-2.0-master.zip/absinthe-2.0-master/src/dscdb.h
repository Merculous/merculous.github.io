/*
 * dscdb.h
 *
 *  Created on: Jan 15, 2012
 *      Author: posixninja
 */

#ifndef DSCDB_H_
#define DSCDB_H_

typedef struct {

} dscdb_t;

#endif /* DSCDB_H_ */
